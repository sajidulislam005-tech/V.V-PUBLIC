
import React from 'react';
import { Camera, Film, Globe, Music, Zap, Heart } from 'lucide-react';
import { Category } from './types';

export const CATEGORIES: Category[] = [
  { id: '1', name: 'Cinematic', slug: 'cinematic', icon: '🎬' },
  { id: '2', name: 'Nature', slug: 'nature', icon: '🌿' },
  { id: '3', name: 'Technology', slug: 'tech', icon: '💻' },
  { id: '4', name: 'Business', slug: 'business', icon: '💼' },
  { id: '5', name: 'Abstract', slug: 'abstract', icon: '🎨' },
  { id: '6', name: 'Travel', slug: 'travel', icon: '✈️' },
];

export const MOCK_VIDEOS = [
  {
    id: 'v1',
    title: 'Neon Tokyo Nightlapse',
    description: 'Breathtaking 4K time-lapse of Shibuya Crossing at night with vibrant neon lights.',
    category: 'travel',
    thumbnail: 'https://picsum.photos/seed/tokyo/800/450',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-city-lights-at-night-reflected-on-the-water-4333-large.mp4',
    isPremium: true,
    downloads: 1240,
    createdAt: '2023-10-12',
    authorId: 'a1',
    resolution: '4K'
  },
  {
    id: 'v2',
    title: 'Misty Mountains Sunrise',
    description: 'Golden hour drone footage over the Swiss Alps with morning mist rolling in.',
    category: 'nature',
    thumbnail: 'https://picsum.photos/seed/mountains/800/450',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-top-aerial-shot-of-a-beautiful-mountain-peak-4886-large.mp4',
    isPremium: false,
    downloads: 8500,
    createdAt: '2023-11-05',
    authorId: 'a1',
    resolution: '1080p'
  },
  {
    id: 'v3',
    title: 'Future Tech Workspace',
    description: 'Clean minimalist workspace with high-end tech gadgets and coding environment.',
    category: 'tech',
    thumbnail: 'https://picsum.photos/seed/tech/800/450',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-hands-typing-on-a-keyboard-in-a-dark-room-4835-large.mp4',
    isPremium: true,
    downloads: 450,
    createdAt: '2023-12-01',
    authorId: 'a1',
    resolution: '4K'
  }
];
