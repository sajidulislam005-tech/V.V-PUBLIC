
export type Role = 'user' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  isPremium: boolean;
  wishlist: string[];
}

export interface Video {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail: string;
  videoUrl: string;
  isPremium: boolean;
  downloads: number;
  createdAt: string;
  authorId: string;
  resolution: '4K' | '1080p' | '720p';
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
}
