
import React from 'react';
import { Github, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white dark:bg-zinc-950 border-t border-gray-100 dark:border-zinc-900 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">V</span>
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">VividStock</span>
            </div>
            <p className="text-gray-500 dark:text-gray-400 max-w-sm">
              Discover millions of premium high-quality stock videos curated by talented creators worldwide. Perfect for your next cinematic project.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Marketplace</h4>
            <ul className="space-y-2 text-gray-500 dark:text-gray-400">
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Premium Videos</a></li>
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Free Footage</a></li>
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Featured Artists</a></li>
              <li><a href="#" className="hover:text-indigo-600 transition-colors">New Releases</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Resources</h4>
            <ul className="space-y-2 text-gray-500 dark:text-gray-400">
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Licensing Guide</a></li>
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Sell Content</a></li>
              <li><a href="#" className="hover:text-indigo-600 transition-colors">Contact Us</a></li>
            </ul>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-gray-100 dark:border-zinc-900">
          <p className="text-gray-400 text-sm">© 2024 VividStock. All rights reserved.</p>
          <div className="flex items-center space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-indigo-600"><Twitter size={20} /></a>
            <a href="#" className="text-gray-400 hover:text-indigo-600"><Instagram size={20} /></a>
            <a href="#" className="text-gray-400 hover:text-indigo-600"><Youtube size={20} /></a>
            <a href="#" className="text-gray-400 hover:text-indigo-600"><Github size={20} /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
