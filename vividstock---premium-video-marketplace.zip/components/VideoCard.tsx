
import React, { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Play, Download, Heart, Crown } from 'lucide-react';
import { Video } from '../types';
import { useAuth } from '../context/AuthContext';

interface VideoCardProps {
  video: Video;
}

const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const { user, toggleWishlist } = useAuth();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const isWishlisted = user?.wishlist.includes(video.id);

  const handleMouseEnter = () => {
    setIsHovered(true);
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  return (
    <div 
      className="group relative bg-white dark:bg-zinc-900 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 dark:border-zinc-800"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Video / Thumbnail Container */}
      <Link to={`/video/${video.id}`} className="block aspect-video relative overflow-hidden bg-zinc-200 dark:bg-zinc-800">
        <img 
          src={video.thumbnail} 
          alt={video.title}
          className={`w-full h-full object-cover transition-opacity duration-300 ${isHovered ? 'opacity-0' : 'opacity-100'}`}
        />
        <video
          ref={videoRef}
          src={video.videoUrl}
          muted
          loop
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex space-x-2">
          {video.isPremium && (
            <span className="bg-amber-500 text-white p-1.5 rounded-lg shadow-lg">
              <Crown size={14} />
            </span>
          )}
          <span className="bg-black/50 backdrop-blur-md text-white px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">
            {video.resolution}
          </span>
        </div>

        {/* Wishlist Button */}
        <button 
          onClick={(e) => { e.preventDefault(); toggleWishlist(video.id); }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all ${
            isWishlisted ? 'bg-red-500 text-white' : 'bg-white/20 text-white hover:bg-white/40'
          }`}
        >
          <Heart size={16} fill={isWishlisted ? 'currentColor' : 'none'} />
        </button>

        {/* Play Overlay */}
        {!isHovered && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/10 transition-opacity group-hover:opacity-0">
             <div className="p-3 rounded-full bg-white/20 backdrop-blur-md">
               <Play size={20} className="text-white fill-white" />
             </div>
          </div>
        )}
      </Link>

      {/* Meta Content */}
      <div className="p-4">
        <div className="flex justify-between items-start mb-1">
          <Link to={`/video/${video.id}`} className="text-sm font-semibold text-gray-900 dark:text-white line-clamp-1 group-hover:text-indigo-600 transition-colors">
            {video.title}
          </Link>
          <span className="text-[10px] text-gray-400 font-medium uppercase">{video.category}</span>
        </div>
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center space-x-1.5 text-xs text-gray-500">
            <Download size={12} />
            <span>{video.downloads.toLocaleString()} downloads</span>
          </div>
          <Link 
            to={`/video/${video.id}`}
            className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            VIEW DETAILS
          </Link>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;
