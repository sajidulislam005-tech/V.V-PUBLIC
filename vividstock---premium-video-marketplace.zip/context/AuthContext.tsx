
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  updatePremium: (status: boolean) => void;
  toggleWishlist: (videoId: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching user from JWT
    const storedUser = localStorage.getItem('vivid_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, pass: string) => {
    // Simulate API Login
    const mockUser: User = {
      id: 'u1',
      name: email.split('@')[0],
      email,
      role: email.includes('admin') ? 'admin' : 'user',
      isPremium: false,
      wishlist: []
    };
    setUser(mockUser);
    localStorage.setItem('vivid_user', JSON.stringify(mockUser));
  };

  const register = async (name: string, email: string, pass: string) => {
    const mockUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      role: 'user',
      isPremium: false,
      wishlist: []
    };
    setUser(mockUser);
    localStorage.setItem('vivid_user', JSON.stringify(mockUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('vivid_user');
  };

  const updatePremium = (status: boolean) => {
    if (user) {
      const updated = { ...user, isPremium: status };
      setUser(updated);
      localStorage.setItem('vivid_user', JSON.stringify(updated));
    }
  };

  const toggleWishlist = (videoId: string) => {
    if (user) {
      const newWishlist = user.wishlist.includes(videoId)
        ? user.wishlist.filter(id => id !== videoId)
        : [...user.wishlist, videoId];
      const updated = { ...user, wishlist: newWishlist };
      setUser(updated);
      localStorage.setItem('vivid_user', JSON.stringify(updated));
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updatePremium, toggleWishlist }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
