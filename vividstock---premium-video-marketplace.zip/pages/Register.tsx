
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
// Added Zap to lucide-react imports
import { Mail, Lock, User as UserIcon, ArrowRight, Zap } from 'lucide-react';

const Register: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await register(name, email, password);
    navigate('/');
  };

  return (
    <div className="min-h-screen flex">
      {/* Form side */}
      <div className="flex-1 flex flex-col justify-center px-8 sm:px-12 lg:px-24 bg-white dark:bg-zinc-950">
        <div className="max-w-md w-full mx-auto">
          <div className="mb-12">
            <Link to="/" className="flex items-center space-x-2 mb-8">
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">V</span>
              </div>
              <span className="text-xl font-bold">VividStock</span>
            </Link>
            <h2 className="text-4xl font-black mb-4">Create Account</h2>
            <p className="text-gray-500">Start your journey into high-end cinematography today.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
             <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Full Name</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-zinc-900 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-indigo-500 transition-all"
                  placeholder="John Doe"
                />
                <UserIcon className="absolute left-4 top-4.5 text-gray-400" size={20} />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Email Address</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-zinc-900 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-indigo-500 transition-all"
                  placeholder="name@example.com"
                />
                <Mail className="absolute left-4 top-4.5 text-gray-400" size={20} />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-widest">Password</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-gray-50 dark:bg-zinc-900 border-none rounded-2xl py-4 pl-12 pr-4 focus:ring-2 focus:ring-indigo-500 transition-all"
                  placeholder="Minimum 8 characters"
                />
                <Lock className="absolute left-4 top-4.5 text-gray-400" size={20} />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-lg shadow-xl shadow-indigo-200 dark:shadow-none transition-all flex items-center justify-center space-x-2"
            >
              <span>Get Started</span>
              <ArrowRight size={20} />
            </button>
          </form>

          <p className="mt-8 text-center text-gray-500">
            Already have an account? <Link to="/login" className="text-indigo-600 font-bold hover:underline">Log in</Link>
          </p>
        </div>
      </div>

      <div className="hidden lg:block flex-1 relative bg-zinc-900">
        <img 
          src="https://images.unsplash.com/photo-1542204172-3c1f44f957e3?auto=format&fit=crop&q=80&w=2070" 
          className="w-full h-full object-cover opacity-60"
          alt="Register backdrop"
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center p-20 text-center">
          <div className="p-4 bg-indigo-600/20 backdrop-blur-md rounded-3xl border border-white/10 mb-8">
            <Zap size={48} className="text-indigo-400" />
          </div>
          <h3 className="text-4xl font-bold text-white mb-6">Built for Professionals.</h3>
          <div className="space-y-6 text-xl text-gray-300">
            <p>Access 100,000+ royalty-free clips.</p>
            <p>Commercial license for all downloads.</p>
            <p>Daily updates from top cinematographers.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
