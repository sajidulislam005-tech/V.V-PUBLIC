
import React from 'react';
import { Heart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { MOCK_VIDEOS } from '../constants';
import VideoCard from '../components/VideoCard';
import { Video } from '../types';

const Wishlist: React.FC = () => {
  const { user } = useAuth();
  
  const wishlistedVideos = (MOCK_VIDEOS as Video[]).filter(v => 
    user?.wishlist.includes(v.id)
  );

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-zinc-950 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-3 mb-12">
          <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-2xl">
            <Heart size={32} className="text-red-500 fill-red-500" />
          </div>
          <div>
            <h1 className="text-4xl font-black">Your Wishlist</h1>
            <p className="text-gray-500 dark:text-gray-400">Videos you've saved for your future projects.</p>
          </div>
        </div>

        {wishlistedVideos.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {wishlistedVideos.map(video => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        ) : (
          <div className="text-center py-32 bg-white dark:bg-zinc-900 rounded-[40px] border border-gray-100 dark:border-zinc-800">
            <Heart size={64} className="mx-auto text-gray-200 mb-6" />
            <h2 className="text-2xl font-bold mb-4">Your wishlist is empty</h2>
            <p className="text-gray-500 mb-10 max-w-sm mx-auto">Explore our collection and click the heart icon to save your favorite shots here.</p>
            <a href="#/" className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all">
              Discover Videos
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default Wishlist;
