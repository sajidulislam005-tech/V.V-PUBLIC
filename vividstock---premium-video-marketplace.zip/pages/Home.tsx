
import React, { useState, useEffect } from 'react';
// Added Crown to lucide-react imports
import { Search, SlidersHorizontal, ChevronRight, Crown } from 'lucide-react';
import VideoCard from '../components/VideoCard';
import { CATEGORIES, MOCK_VIDEOS } from '../constants';
import { Video } from '../types';

const Home: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API fetch
    setTimeout(() => {
      let filtered = MOCK_VIDEOS as Video[];
      if (selectedCategory !== 'all') {
        filtered = filtered.filter(v => v.category === selectedCategory);
      }
      setVideos(filtered);
      setLoading(false);
    }, 800);
  }, [selectedCategory]);

  return (
    <div className="pb-20">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Video (Mock) */}
        <div className="absolute inset-0 bg-zinc-900">
          <img 
            src="https://images.unsplash.com/photo-1492691523567-6170c2495db7?auto=format&fit=crop&q=80&w=2070" 
            className="w-full h-full object-cover opacity-50 blur-sm"
            alt="Hero background"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/60"></div>
        </div>

        <div className="relative z-10 max-w-4xl px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Cinematic visuals for your <span className="text-indigo-400">biggest ideas</span>
          </h1>
          <p className="text-xl text-gray-200 mb-10 max-w-2xl mx-auto">
            Access thousands of premium high-resolution stock videos curated by experts. From nature to futuristic tech.
          </p>
          
          <div className="max-w-2xl mx-auto">
            <div className="relative group">
              <input 
                type="text" 
                placeholder="Search premium videos, aerials, time-lapse..." 
                className="w-full h-16 pl-14 pr-32 rounded-2xl bg-white/95 text-lg text-zinc-900 border-none shadow-2xl focus:ring-4 focus:ring-indigo-500/30 transition-all outline-none"
              />
              <Search className="absolute left-5 top-5 text-gray-400 group-hover:text-indigo-600 transition-colors" size={24} />
              <button className="absolute right-3 top-3 bottom-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all transform hover:scale-105">
                Search
              </button>
            </div>
            <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm text-gray-300">
              <span>Trending:</span>
              <a href="#" className="hover:text-white underline">Drone</a>
              <a href="#" className="hover:text-white underline">Slow Motion</a>
              <a href="#" className="hover:text-white underline">Cyberpunk</a>
              <a href="#" className="hover:text-white underline">Coffee</a>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        {/* Filters & Categories */}
        <div className="flex flex-col md:flex-row items-center justify-between mb-10 gap-6">
          <div className="flex items-center space-x-2 overflow-x-auto pb-2 w-full md:w-auto no-scrollbar">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-6 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-all ${
                selectedCategory === 'all' 
                  ? 'bg-indigo-600 text-white shadow-lg' 
                  : 'bg-gray-100 dark:bg-zinc-900 hover:bg-gray-200 dark:hover:bg-zinc-800'
              }`}
            >
              All Assets
            </button>
            {CATEGORIES.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.slug)}
                className={`px-6 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap flex items-center space-x-2 transition-all ${
                  selectedCategory === cat.slug 
                    ? 'bg-indigo-600 text-white shadow-lg' 
                    : 'bg-gray-100 dark:bg-zinc-900 hover:bg-gray-200 dark:hover:bg-zinc-800'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
              </button>
            ))}
          </div>
          
          <button className="flex items-center space-x-2 px-5 py-2.5 bg-white dark:bg-zinc-900 border border-gray-200 dark:border-zinc-800 rounded-xl hover:bg-gray-50 dark:hover:bg-zinc-800 transition-all font-medium">
            <SlidersHorizontal size={18} />
            <span>Advanced Filters</span>
          </button>
        </div>

        {/* Video Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {loading ? (
            Array(6).fill(0).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-video bg-gray-200 dark:bg-zinc-800 rounded-2xl mb-4"></div>
                <div className="h-4 bg-gray-200 dark:bg-zinc-800 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-zinc-800 rounded w-1/2"></div>
              </div>
            ))
          ) : (
            videos.map(video => (
              <VideoCard key={video.id} video={video} />
            ))
          )}
        </div>

        {!loading && videos.length === 0 && (
          <div className="py-20 text-center">
            <h3 className="text-2xl font-bold mb-2">No videos found</h3>
            <p className="text-gray-500">Try adjusting your filters or search keywords.</p>
          </div>
        )}

        {/* Call to Action */}
        <section className="mt-24 p-8 md:p-16 rounded-[40px] bg-gradient-to-br from-indigo-600 to-purple-700 text-white relative overflow-hidden">
          <div className="relative z-10 grid md:grid-cols-2 items-center gap-12">
            <div>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">Become a Premium Member</h2>
              <ul className="space-y-4 mb-10 text-lg opacity-90">
                <li className="flex items-center space-x-3">
                  <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs">✓</span>
                  <span>Access to exclusive 4K & 8K content</span>
                </li>
                <li className="flex items-center space-x-3">
                  <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs">✓</span>
                  <span>Commercial use license included</span>
                </li>
                <li className="flex items-center space-x-3">
                  <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs">✓</span>
                  <span>Unlimited downloads & fast servers</span>
                </li>
              </ul>
              <button className="bg-white text-indigo-600 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-gray-100 transition-all flex items-center space-x-2 group">
                <span>See Pricing Plans</span>
                <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
            <div className="hidden md:block">
              <div className="relative w-full aspect-square bg-white/10 rounded-[60px] flex items-center justify-center border border-white/20 backdrop-blur-sm">
                <Crown size={120} className="text-white/40 animate-bounce" />
              </div>
            </div>
          </div>
          {/* Decorative shapes */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/30 rounded-full -ml-32 -mb-32 blur-3xl"></div>
        </section>
      </div>
    </div>
  );
};

export default Home;
