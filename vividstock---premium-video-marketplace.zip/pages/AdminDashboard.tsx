
import React, { useState } from 'react';
import { Upload, Trash2, Edit, Users, Video, BarChart3, Plus, Search, ExternalLink } from 'lucide-react';
import { MOCK_VIDEOS } from '../constants';
import { Video as VideoType } from '../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'videos' | 'users' | 'stats'>('videos');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [videos, setVideos] = useState<VideoType[]>(MOCK_VIDEOS as VideoType[]);

  const handleDelete = (id: string) => {
    if (window.confirm("Delete this video permanently?")) {
      setVideos(videos.filter(v => v.id !== id));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-zinc-950 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white dark:bg-zinc-900 border-r border-gray-100 dark:border-zinc-800 p-6 hidden md:block">
        <div className="mb-10 px-2">
          <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Admin Control</span>
        </div>
        <nav className="space-y-2">
          {[
            { id: 'videos', label: 'Manage Videos', icon: Video },
            { id: 'users', label: 'User Directory', icon: Users },
            { id: 'stats', label: 'Analytics', icon: BarChart3 }
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium transition-all ${
                activeTab === item.id 
                  ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' 
                  : 'text-gray-500 hover:bg-gray-50 dark:hover:bg-zinc-800'
              }`}
            >
              <item.icon size={20} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-10">
            <div>
              <h1 className="text-3xl font-bold">Dashboard</h1>
              <p className="text-gray-500">Welcome back, Administrator.</p>
            </div>
            {activeTab === 'videos' && (
              <button 
                onClick={() => setShowUploadModal(true)}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl font-bold flex items-center space-x-2 transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
              >
                <Plus size={20} />
                <span>Upload Video</span>
              </button>
            )}
          </div>

          {activeTab === 'videos' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between bg-white dark:bg-zinc-900 p-4 rounded-2xl border border-gray-100 dark:border-zinc-800">
                <div className="relative flex-1 max-w-sm">
                  <Search size={18} className="absolute left-3 top-3 text-gray-400" />
                  <input 
                    type="text" 
                    placeholder="Search by title or category..." 
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 dark:bg-zinc-800 border-none rounded-xl"
                  />
                </div>
                <div className="flex items-center space-x-4">
                   <select className="bg-gray-50 dark:bg-zinc-800 border-none rounded-xl px-4 py-2.5 text-sm font-medium">
                     <option>All Categories</option>
                     <option>Nature</option>
                     <option>Travel</option>
                   </select>
                </div>
              </div>

              <div className="bg-white dark:bg-zinc-900 rounded-3xl overflow-hidden border border-gray-100 dark:border-zinc-800">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 dark:bg-zinc-800/50">
                    <tr>
                      <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase">Preview</th>
                      <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase">Title & Category</th>
                      <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase">Downloads</th>
                      <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase">Type</th>
                      <th className="px-6 py-4 text-xs font-bold text-gray-400 uppercase text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-zinc-800">
                    {videos.map(v => (
                      <tr key={v.id} className="hover:bg-gray-50 dark:hover:bg-zinc-800/30 transition-colors">
                        <td className="px-6 py-4">
                          <div className="w-16 h-10 rounded-lg overflow-hidden bg-gray-200">
                            <img src={v.thumbnail} className="w-full h-full object-cover" alt="" />
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-bold text-sm">{v.title}</div>
                          <div className="text-xs text-gray-400">{v.category}</div>
                        </td>
                        <td className="px-6 py-4 text-sm font-medium">{v.downloads}</td>
                        <td className="px-6 py-4">
                          {v.isPremium ? (
                            <span className="px-2 py-1 bg-amber-50 text-amber-600 rounded-lg text-[10px] font-bold uppercase">Premium</span>
                          ) : (
                            <span className="px-2 py-1 bg-green-50 text-green-600 rounded-lg text-[10px] font-bold uppercase">Free</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <div className="flex items-center justify-end space-x-2">
                            <button className="p-2 text-gray-400 hover:text-indigo-600 transition-colors"><Edit size={18} /></button>
                            <button onClick={() => handleDelete(v.id)} className="p-2 text-gray-400 hover:text-red-600 transition-colors"><Trash2 size={18} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
             <div className="bg-white dark:bg-zinc-900 rounded-3xl p-10 text-center border border-gray-100 dark:border-zinc-800">
               <Users size={48} className="mx-auto text-gray-300 mb-4" />
               <h3 className="text-xl font-bold mb-2">User Management System</h3>
               <p className="text-gray-500 max-w-md mx-auto">This module connects to your MongoDB User collection. You can manage roles, view purchase history and toggle premium status manually.</p>
               <button className="mt-6 px-6 py-3 bg-gray-100 dark:bg-zinc-800 rounded-xl font-bold">Connect Database</button>
             </div>
          )}
        </div>
      </main>

      {/* Upload Modal Simulation */}
      {showUploadModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowUploadModal(false)}></div>
          <div className="relative bg-white dark:bg-zinc-900 w-full max-w-2xl rounded-[40px] p-10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <h2 className="text-2xl font-bold mb-8">Upload New Asset</h2>
            <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setShowUploadModal(false); }}>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-400 uppercase">Video Title</label>
                  <input type="text" className="w-full bg-gray-50 dark:bg-zinc-800 border-none rounded-xl p-3" placeholder="Cinematic Forest..." required />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-400 uppercase">Category</label>
                  <select className="w-full bg-gray-50 dark:bg-zinc-800 border-none rounded-xl p-3">
                    <option>Nature</option>
                    <option>Travel</option>
                    <option>Business</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase">Description</label>
                <textarea className="w-full bg-gray-50 dark:bg-zinc-800 border-none rounded-xl p-3 h-24" placeholder="Brief details about the scene..."></textarea>
              </div>

              <div className="border-2 border-dashed border-gray-200 dark:border-zinc-800 rounded-3xl p-10 text-center hover:border-indigo-500/50 transition-colors cursor-pointer group">
                <div className="w-12 h-12 bg-gray-50 dark:bg-zinc-800 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-indigo-50 transition-colors">
                  <Upload size={24} className="text-gray-400 group-hover:text-indigo-500" />
                </div>
                <p className="font-bold text-gray-600 dark:text-gray-300">Drag & Drop Video File</p>
                <p className="text-sm text-gray-400">Maximum file size: 500MB (MP4, MOV)</p>
              </div>

              <div className="flex items-center justify-between py-2">
                <div className="flex items-center space-x-2">
                  <input type="checkbox" className="w-5 h-5 rounded border-gray-300 text-indigo-600" id="premium" />
                  <label htmlFor="premium" className="font-bold text-sm">Mark as Premium Asset</label>
                </div>
                <div className="flex space-x-3">
                  <button type="button" onClick={() => setShowUploadModal(false)} className="px-6 py-3 rounded-xl font-bold text-gray-500 hover:bg-gray-100 transition-all">Cancel</button>
                  <button type="submit" className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-lg transition-all">Upload Asset</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
