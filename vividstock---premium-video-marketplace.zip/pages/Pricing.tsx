
import React from 'react';
import { Crown, Check, Zap, Rocket } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Pricing: React.FC = () => {
  const { updatePremium, user } = useAuth();

  const handleSubscribe = () => {
    // Simulate Stripe Checkout
    const confirmed = window.confirm("Confirm payment of $19.99 for VividStock Premium Monthly?");
    if (confirmed) {
      updatePremium(true);
      alert("Successfully upgraded to Premium!");
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-20 bg-gray-50 dark:bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-black mb-6">Elevate your production.</h1>
        <p className="text-xl text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
          One simple subscription for all the high-end assets you need to create cinematic stories.
        </p>
      </div>

      <div className="max-w-5xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Free Plan */}
        <div className="bg-white dark:bg-zinc-900 rounded-[40px] p-10 border border-gray-100 dark:border-zinc-800 transition-all hover:scale-[1.02]">
          <div className="mb-8">
            <span className="text-gray-400 font-bold uppercase tracking-widest text-xs">Standard</span>
            <h3 className="text-3xl font-bold mt-2">Free</h3>
            <p className="text-gray-500 mt-2">For personal hobby projects</p>
          </div>
          
          <ul className="space-y-5 mb-10">
            {[
              "1080p Standard Downloads",
              "Personal Use License",
              "Limited Library Access",
              "Attribution Required"
            ].map((feature, i) => (
              <li key={i} className="flex items-center space-x-3 text-gray-600 dark:text-gray-400">
                <Check size={18} className="text-green-500" />
                <span>{feature}</span>
              </li>
            ))}
          </ul>
          
          <button 
            disabled
            className="w-full py-4 rounded-2xl font-bold bg-gray-100 dark:bg-zinc-800 text-gray-400 cursor-not-allowed"
          >
            Current Plan
          </button>
        </div>

        {/* Premium Plan */}
        <div className="relative bg-white dark:bg-zinc-900 rounded-[40px] p-10 border-4 border-indigo-600 shadow-2xl shadow-indigo-200 dark:shadow-none transition-all hover:scale-[1.02] overflow-hidden">
          <div className="absolute top-0 right-0 px-8 py-2 bg-indigo-600 text-white font-bold text-sm transform rotate-45 translate-x-8 translate-y-4">
            BEST VALUE
          </div>
          
          <div className="mb-8">
            <div className="flex items-center space-x-2 text-indigo-600 font-bold uppercase tracking-widest text-xs">
              <Crown size={14} />
              <span>Premium Pro</span>
            </div>
            <div className="flex items-baseline mt-2">
              <span className="text-5xl font-black">$19.99</span>
              <span className="text-gray-500 font-medium ml-2">/ month</span>
            </div>
            <p className="text-gray-500 mt-2">Unlimited power for professionals</p>
          </div>
          
          <ul className="space-y-5 mb-10">
            {[
              "4K & 8K Ultra HD Downloads",
              "Full Commercial License",
              "Unlimited Library Access",
              "No Attribution Needed",
              "Priority Customer Support",
              "New Content Weekly"
            ].map((feature, i) => (
              <li key={i} className="flex items-center space-x-3 text-gray-900 dark:text-gray-100">
                <Zap size={18} className="text-amber-500 fill-amber-500" />
                <span className="font-medium">{feature}</span>
              </li>
            ))}
          </ul>
          
          <button 
            onClick={handleSubscribe}
            className={`w-full py-4 rounded-2xl font-bold text-white transition-all transform active:scale-95 ${
              user?.isPremium ? 'bg-green-600 cursor-default' : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {user?.isPremium ? 'Already Subscribed' : 'Get Started Now'}
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 mt-20 text-center">
        <p className="text-gray-400 text-sm">
          All payments are processed securely by Stripe. Cancel anytime with one click in your account settings.
        </p>
      </div>
    </div>
  );
};

export default Pricing;
