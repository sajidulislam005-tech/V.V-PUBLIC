
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Download, Share2, Heart, Flag, ShieldCheck, Crown, ArrowLeft, MoreHorizontal } from 'lucide-react';
import { MOCK_VIDEOS } from '../constants';
import { useAuth } from '../context/AuthContext';
import { Video } from '../types';
import VideoCard from '../components/VideoCard';

const VideoDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, toggleWishlist } = useAuth();
  const [video, setVideo] = useState<Video | null>(null);
  const [relatedVideos, setRelatedVideos] = useState<Video[]>([]);
  const [downloading, setDownloading] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    const found = MOCK_VIDEOS.find(v => v.id === id);
    if (found) {
      setVideo(found as Video);
      setRelatedVideos(MOCK_VIDEOS.filter(v => v.id !== id) as Video[]);
    }
  }, [id]);

  if (!video) return <div className="min-h-screen flex items-center justify-center">Loading Video...</div>;

  const isWishlisted = user?.wishlist.includes(video.id);

  const handleDownload = () => {
    if (video.isPremium && !user?.isPremium) {
      setShowPremiumModal(true);
      return;
    }
    
    setDownloading(true);
    // Simulate download logic
    setTimeout(() => {
      setDownloading(false);
      alert('Download started for ' + video.title);
      // In production, we'd trigger a direct file download here
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-zinc-950 pb-20">
      {/* Top Bar */}
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="flex items-center space-x-2 text-gray-500 hover:text-indigo-600 transition-colors">
          <ArrowLeft size={20} />
          <span className="font-medium">Back to search</span>
        </button>
        <div className="flex items-center space-x-4">
          <button className="p-2 text-gray-500 hover:text-indigo-600"><Share2 size={20} /></button>
          <button className="p-2 text-gray-500 hover:text-amber-600"><Flag size={20} /></button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-3 gap-12 mt-4">
        {/* Left: Player Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="aspect-video bg-black rounded-3xl overflow-hidden shadow-2xl relative">
            <video 
              src={video.videoUrl} 
              controls 
              autoPlay 
              className="w-full h-full"
              poster={video.thumbnail}
            />
          </div>

          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-8 shadow-sm border border-gray-100 dark:border-zinc-800">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{video.title}</h1>
              <div className="flex items-center space-x-4">
                 <button 
                  onClick={() => toggleWishlist(video.id)}
                  className={`flex items-center space-x-2 px-6 py-3 rounded-2xl font-bold transition-all ${
                    isWishlisted ? 'bg-red-50 text-red-600' : 'bg-gray-50 dark:bg-zinc-800 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-zinc-700'
                  }`}
                >
                  <Heart size={20} fill={isWishlisted ? 'currentColor' : 'none'} />
                  <span>{isWishlisted ? 'Saved' : 'Save'}</span>
                </button>
              </div>
            </div>

            <p className="text-gray-600 dark:text-gray-400 text-lg leading-relaxed mb-8">
              {video.description}
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-8 border-y border-gray-100 dark:border-zinc-800">
              <div>
                <span className="block text-xs text-gray-400 font-bold uppercase mb-1">Resolution</span>
                <span className="text-lg font-semibold text-gray-900 dark:text-white">{video.resolution}</span>
              </div>
              <div>
                <span className="block text-xs text-gray-400 font-bold uppercase mb-1">Category</span>
                <span className="text-lg font-semibold text-gray-900 dark:text-white capitalize">{video.category}</span>
              </div>
              <div>
                <span className="block text-xs text-gray-400 font-bold uppercase mb-1">Downloads</span>
                <span className="text-lg font-semibold text-gray-900 dark:text-white">{video.downloads.toLocaleString()}</span>
              </div>
              <div>
                <span className="block text-xs text-gray-400 font-bold uppercase mb-1">Format</span>
                <span className="text-lg font-semibold text-gray-900 dark:text-white">MP4</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Actions & License */}
        <div className="space-y-8">
          {/* Download Panel */}
          <div className="bg-white dark:bg-zinc-900 rounded-3xl p-8 shadow-sm border border-gray-100 dark:border-zinc-800">
            <h3 className="text-xl font-bold mb-6 flex items-center space-x-2">
              <Download size={22} className="text-indigo-600" />
              <span>Download File</span>
            </h3>

            <div className="space-y-4 mb-8">
              <button className="w-full flex items-center justify-between p-4 rounded-2xl border-2 border-indigo-600 bg-indigo-50 dark:bg-indigo-900/10 text-indigo-600 dark:text-indigo-400">
                <div className="text-left">
                  <span className="block font-bold">Standard HD</span>
                  <span className="text-xs opacity-75">1920 x 1080 • MP4</span>
                </div>
                <span className="font-bold">FREE</span>
              </button>
              <button className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 border-transparent bg-gray-50 dark:bg-zinc-800 hover:border-indigo-600/30 transition-all ${video.isPremium ? 'opacity-50' : ''}`}>
                <div className="text-left">
                  <span className="block font-bold flex items-center space-x-2">
                    <span>Ultra 4K</span>
                    {video.isPremium && <Crown size={14} className="text-amber-500" />}
                  </span>
                  <span className="text-xs text-gray-500">3840 x 2160 • MP4</span>
                </div>
                <span className="font-bold text-gray-500">{video.isPremium ? 'PREMIUM' : 'FREE'}</span>
              </button>
            </div>

            <button 
              onClick={handleDownload}
              disabled={downloading}
              className={`w-full py-5 rounded-2xl font-bold text-white shadow-xl transition-all ${
                downloading ? 'bg-gray-400' : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95'
              }`}
            >
              {downloading ? 'Processing...' : 'Download Now'}
            </button>

            <div className="mt-6 flex items-center justify-center space-x-2 text-xs text-gray-400 font-medium">
              <ShieldCheck size={14} className="text-green-500" />
              <span>VividStock License • Safe & Secure</span>
            </div>
          </div>

          {/* License Info */}
          <div className="bg-gradient-to-br from-zinc-800 to-black p-8 rounded-3xl text-white">
            <h4 className="font-bold mb-4 flex items-center space-x-2">
              <span className="p-1 bg-white/10 rounded">📄</span>
              <span>License Terms</span>
            </h4>
            <p className="text-sm text-gray-400 mb-6">
              You can use this video for your personal and commercial projects. No attribution required, although appreciated.
            </p>
            <Link to="/pricing" className="text-indigo-400 text-sm font-bold hover:underline">Read full license →</Link>
          </div>
        </div>
      </div>

      {/* Related Videos Section */}
      <div className="max-w-7xl mx-auto px-4 mt-20">
        <h2 className="text-2xl font-bold mb-10 flex items-center space-x-3">
          <div className="w-1.5 h-8 bg-indigo-600 rounded-full"></div>
          <span>Similar Recommendations</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {relatedVideos.map(v => <VideoCard key={v.id} video={v} />)}
        </div>
      </div>

      {/* Premium Upgrade Modal */}
      {showPremiumModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowPremiumModal(false)}></div>
          <div className="relative bg-white dark:bg-zinc-900 w-full max-w-lg rounded-[40px] p-10 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-300">
             {/* Background glow */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/20 rounded-full blur-3xl"></div>
            
            <div className="text-center relative">
              <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
                <Crown size={40} className="text-amber-500" />
              </div>
              <h2 className="text-3xl font-bold mb-4">Premium Required</h2>
              <p className="text-gray-500 dark:text-gray-400 mb-10">
                This asset is part of our exclusive collection. Upgrade your plan to get access to 4K downloads and 100+ new videos weekly.
              </p>
              
              <div className="space-y-4">
                <Link 
                  to="/pricing"
                  className="block w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold transition-all"
                >
                  Upgrade to Premium
                </Link>
                <button 
                  onClick={() => setShowPremiumModal(false)}
                  className="block w-full py-4 text-gray-400 hover:text-gray-600 font-semibold"
                >
                  Maybe Later
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoDetails;
